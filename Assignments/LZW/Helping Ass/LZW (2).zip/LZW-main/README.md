# LZW
LZW compression implementation in python
you can find the actual implementation in LZW.py file while Encoder_Decoder.py is just an interactive console interface 
